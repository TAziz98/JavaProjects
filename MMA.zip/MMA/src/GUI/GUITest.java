package GUI;

import java.io.IOException;

public class GUITest {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		Criteria criteria = new Criteria();
		criteria.show();
	}

}
