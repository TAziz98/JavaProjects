package MMA;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Association {
	
	private Set<Fighter>  fighters = new HashSet<Fighter>();
	
	public Set<Fighter> getFighters() {
		return new HashSet<>(fighters);
	}

	public void signFighter(Fighter fighter) {
		if(fighter==null) {
			throw new RuntimeException("Given parameter(fighter) is null");
		}
		else {
			if(!fighters.contains(fighter)){
				fighters.add(fighter);
				fighter.setAssociation(this);
			}else {
				throw new RuntimeException("Fighter is already in Association");
			}
		}	
	}
	
	public void unsignFighter(Fighter fighter) {
		if(fighter==null) {
			throw new RuntimeException("Given parameter(fighter) is null");
		}
		else {
			if(!fighters.contains(fighter)){
				throw new RuntimeException("Fighter is not in Association");
			}else {
				fighters.remove(fighter);
				if(fighter.getAssociation()!=null) {
				fighter.refuceAssociation(this);
				}
			}
		}	
	}
}
