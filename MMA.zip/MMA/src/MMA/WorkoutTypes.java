package MMA;

public enum WorkoutTypes {
  Grappling,
  FullContact,
  CrossFit
}
