package MMA;

public interface TrainingArena{
 	public void setRentPrice(Integer periodOfRenting);
	public Integer getRentPrice();
}
