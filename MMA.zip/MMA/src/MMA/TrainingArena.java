package MMA;

public interface TrainingArena{
 	public void setRentPrice(int periodOfRenting);
	public int getRentPrice();
}
