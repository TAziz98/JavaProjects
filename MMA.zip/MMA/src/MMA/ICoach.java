package MMA;

public interface ICoach {
	int getexperienceAsCoach();
	void setExperienceAsCoach(int experienceAsCoach);
	Integer getSalaryAsCoach();
	void setSalaryAsCoach(Integer salary);
	
}
