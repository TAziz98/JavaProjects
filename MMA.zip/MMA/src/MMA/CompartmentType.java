package MMA;

public enum CompartmentType {
	BattleArena,
	TrainingArena

}
