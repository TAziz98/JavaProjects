package MMA;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;
public abstract class Person implements Comparable<Person> {
    
	
	private String name;
	private String lastName;
	private int age;
	private Ethnicity ethnicity;
	private Integer experienceCareer;
	public final static int minAge = 18;
	public final static int maxAge = 47;
	
	private static TreeSet<Person> personExtent = new TreeSet<>(Comparator.reverseOrder());

	
	public Person(String name, String lastName, Integer experienceCareer, int age, Ethnicity ethnicity) {
		this.setName(name);
		this.setAge(age);
		this.setLastName(lastName);
		this.setExperienceCareer(experienceCareer);
		this.setEthnicity(ethnicity);
		this.personExtent.add(this);
	}
	

	
	public abstract Integer getSalary();
	
	
	public void setEthnicity(Ethnicity ethnicity) {
		if (ethnicity == null) 
		throw new RuntimeException("Given parameter(ethnicity) is null");
		else {
		if(personExtent.stream().anyMatch(p->p.getEthnicity()==ethnicity))
	    throw new RuntimeException("This ethnicity is alredy other person's");
		else
		this.ethnicity = ethnicity;
		 }
	}

	
	public String getName() {
		return name;
	}

	//Custom constraint
	public void setName(String name) {
		  if(name == null)
	          throw new RuntimeException("Given parameter(name) is null");
	      if(name.matches("[A-Z][a-z]*"))
	          throw new RuntimeException("Given name is not valid");
	      else
		this.name = name;
	}

	public String getLastName() {
		return lastName;
	}

	//dedicated setter unique constraint
	public void setLastName(String lastName) {
		if(lastName==null)
			throw new RuntimeException("Given parameter(sponsor) is null");
		else {
			if(this.personExtent.stream().anyMatch(p->p.getLastName().equals(lastName)))
				throw new  RuntimeException("Last Name should be unique");
			else
		this.lastName = lastName;
		}
	}

	public int getExperienceCareer() {
		return experienceCareer;
	}

	public void setExperienceCareer(Integer experienceCareer) {
		if(experienceCareer==null)
		 throw new RuntimeException("Given parameter(sponsor) is null");
		else {
		if(experienceCareer<0)
			throw new IllegalArgumentException("can't be negative");
		else
		this.experienceCareer = experienceCareer;
		}
	}
	
	  public Ethnicity getEthnicity() {
			return ethnicity;
		}

		public static Set<Person> getPersonExtent() {
			return new TreeSet<>(personExtent);
		}
		
		public int getAge() {
			return age;
		}

		//attributes constraints
		public void setAge(int age) {
			if(age<minAge || age>maxAge )
				throw new IllegalArgumentException(String.format("Age can't be less than (%s) and more than %s", minAge,maxAge));
			else {
				if(age < this.age) 
					throw new IllegalArgumentException("Age never decreases.");
				else
			this.age = age;
			}
		}

	
}
