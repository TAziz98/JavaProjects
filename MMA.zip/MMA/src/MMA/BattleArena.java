package MMA;

public interface BattleArena {
	public void setHoldDownPrice(Integer periodHoldingDown);
	public Integer getHoldDownPrice();


}
