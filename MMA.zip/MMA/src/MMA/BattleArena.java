package MMA;

public interface BattleArena {
	public void setHoldDownPrice(int periodHoldingDown);
	public int getHoldDownPrice();


}
